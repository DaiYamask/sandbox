package com.example.reactivefileupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveFileUploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
