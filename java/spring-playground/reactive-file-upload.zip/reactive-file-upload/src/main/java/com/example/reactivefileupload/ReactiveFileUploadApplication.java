package com.example.reactivefileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactiveFileUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReactiveFileUploadApplication.class, args);
	}

}
